"""
Filename: Warm-Up_4_QC_Hello.py
Author: <Lastname, Firstname>
Created: <MM/DD/YYYY>
Instructor: Holtslander
"""

def hello():
    """
    Asks the user to input their name. Stores their name in a variable and prints the message:
    "Hello, <name>"
    :return: None
    """
    ### YOUR CODE GOES HERE ###


### YOU SHOULD NOT NEED TO CHANGE ANYTHING HERE ###
if __name__ == '__main__':
    hello()